chrome.devtools.panels.create(
  "Simple Data Layer Viewer - Live",
  "/img/logo.png",
  "/html/devpanel.html",
  null
);
